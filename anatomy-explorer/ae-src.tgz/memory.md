# memory.md — Anatomy Explorer decision log

The durable memory of this product. Read before making decisions. Append when a decision is made;
never silently rewrite history. Decisions are `A-###` here; `D-###` refers to the exercise
library's log in `../patient-library/memory.md`.

---

## Current state — 2026-08-26

**Unified foundation, pre-3D.** The local content snapshot, schemas, compliance/anatomy checks,
legal/UI shell, preview and handbook routes, QR tooling, and locator-to-area handoff are present.
The remaining product signature is the full-body Three.js experience and its visual/accessibility QA.
Release is also blocked on executable dependency verification, clinician review metadata, draft safety
copy policy, image enforcement, unpublished-area filtering, explicit item priority, and consistent
safety behavior across entry paths.

---

## The people

- **Afsal** — builds it. Not a clinician.
- **The physiotherapist** — owns every clinical word. Currently entering exercise content into the
  Google Sheet for the library (library D-028, 2026-08-25).
- **Agents** — Hermes/GLM 5.3, Antigravity/Gemini, Claude, and Codex work under the supervised
  assignments in `../MODULE-MAP.md` and `handoffs/AGENT-PROMPTS.md`.

---

## Decisions

### A-021 · Module H1: Clinic handoff, approved search, QR modal, deep-link focus, and print stylesheets
**2026-08-27 · Afsal + Antigravity / Gemini · implements handbook sharing workflows**
Implemented the complete clinic-guided handbook workflow:
1. `/clinic` provides an unlisted, tablet-friendly physiotherapist catalog for instant search, copy link, QR generation, patient view, and printable handouts.
2. `HandbookSearch.astro` provides keyboard-navigable approved-name search across published body areas, stretching, and exercise protocols (with strict condition-name suppression).
3. `ShareModal.astro` renders scannable QR codes dynamically with visible text URL fallbacks and clipboard copy.
4. Deep links `#item-id` automatically highlight, focus, and scroll targeted exercise cards into view.
5. `@media print` formats patient-ready handouts with clean typography, dosage grid, safety warnings, and hides interactive controls.

### A-020 · Eight open launch decisions receive conservative preview defaults
**2026-08-27 · Afsal + Codex · implementation default, not clinical/legal approval**
`docs/LAUNCH-DECISION-PACK.md` defines buildable defaults for classification posture, stop-screen
structure and draft wording, disclaimer copy, media sourcing/style, highlight sign-off, domain pattern,
exercise priority, and page structure. The product uses the conservative option whenever review is
missing: stricter compliance, no guessed emergency destination, no published draft copy, no inferred
priority, controlled media, and complete direct/accessible routes. Human approval remains mandatory
where the pack marks it; an implementation default must never be represented as sign-off.

### A-019 · Current execution uses supervised modules S0/S1/H1/V1/V2/Q1/R1
**2026-08-27 · Afsal + Codex · supersedes A-008/A-009 for execution only**
The detailed M0–M9 handoffs were written against an older source tree and are retained as historical
acceptance evidence, not copy-ready assignments. The current build uses a smaller dependency-ordered
module map in `../MODULE-MAP.md`: Hermes/GLM 5.3 owns stabilization and correctness-critical content/
safety work; Antigravity/Gemini owns handbook sharing workflows; Claude reviews without editing; and
Codex supervises integration and exclusively owns the visual, animation, and Three.js surfaces.

The duplicate historical decision identifiers A-015 and A-016 are acknowledged. Do not renumber old
entries silently because external documents may cite them; cite the decision title alongside the ID
until a deliberate migration table is created.

### A-015 · `exercise` stays singular; every path goes through `lib/section.ts`
**2026-08-26 · Afsal + Claude · closes the PORT-CHECKLIST Tier 3 naming trap**
`section` in the data is `exercise`, singular. The A-014 shell hardcoded `/exercises/`, so
`[section]/[area_id].astro` emitted `/exercise/neck/` while the index cards linked to
`/exercises/neck/` — every exercise link 404'd, and it read as a routing bug rather than a
pluralisation one. Resolved **singular**: it matches the data, matches the live app's own
`index.astro`, and matches URLs already sent to patients on a QR code.

The decision is enforced structurally, not by discipline: `src/lib/section.ts` owns `sectionPath`,
`areaPath`, labels and the `Section` type, and no other file contains the string `/exercise` or
`/exercises`. If that literal reappears anywhere else, the bug is coming back.

### A-016 · The locator hands off through a real `/area/<id>/` route
**2026-08-26 · Afsal + Claude · implements MERGE-PLAN region→area resolution**
The locator previously contained two links — home and the skip link — so the home page's primary
call to action led to a screen a patient could only back out of. Region→area resolution now lands
on its own prerendered page rather than a JS screen inside the locator, because a patient can be
sent "your neck page" directly, it works with JS disabled, and the back button behaves.

Consequence worth keeping: every destination in the locator is a server-rendered `<a href>`. No
client-side routing and no JS-built URLs, per PRD §10.

### A-017 · The red flags appear on the item page, not only in the locator gate
**2026-08-26 · Afsal + Claude · supplements A-007, does not supersede it**
Walking the app as a patient showed the A-007 gate was bypassable: the home page's "Stretching"
and "Exercise Protocols" entrances go section → area → items and never touch the locator, so on
those routes the eight triggers were never shown at all. A-007 puts the check "before any exercise
handoff", and those are handoffs.

`RedFlags.astro` now renders the same eight `SAFETY_RULES` on the area item page, whichever route
reached it. It is a **panel, not a second blocking gate**: a patient opens that page daily, and a
wall they tap through every day is a wall they stop reading by the third day. The blocking gate
stays in the locator as a first-visit orientation step.

It is also styled deliberately quiet — bordered notice, warning rule and heading, not a solid
alarm block. The first version stacked two full-width yellow panels above the fold and pushed the
first exercise a screen and a half down. Alarm styling on something seen every day is how a
warning becomes wallpaper.

**Still open for the clinician:** all eight triggers are `status: 'draft'` with empty
`reviewedBy`. `check:anatomy` reports it on every build.

### A-018 · One compliance list, one joint table, one publication rule
**2026-08-26 · Afsal + Claude · closes three duplications found in the 2026-08-26 review**
Three places had grown a second, weaker copy of something that should exist once:

- `lib/anatomy/content-validation.ts` carried its own 7-pattern `BANNED_LANGUAGE` against
  `compliance.ts`'s 53 — with **zero condition names and zero booking CTAs**, the two groups that
  carry the legal weight. Retired; `education-validation.ts` imports the real list.
- `body-regions.ts` hand-listed nine regions including `upper-back` and `foot` (no library area —
  dead ends) and omitted `elbow` (two exercises — unreachable). That is verbatim the drift A-005
  was written after, live for a second time. Geometry now derives from the joint table in
  `lib/anatomy/geometry/`, availability derives from published content, and the
  `check:anatomy` script A-005 promised finally exists and fails the build on drift.
- "Published AND has published items" now lives once, in `lib/library.ts`, and is asserted again
  by `check:anatomy`. Pages no longer each decide what reachable means.

The general rule this encodes, from `compliance.ts`'s own header: *two copies of a compliance list
is two chances for them to drift.* They had drifted, in the direction of less protection, in the
folder that is meant to become the product.

### A-011 · Unified application replaces the additive split
**2026-08-26 · Afsal**
The anatomy locator and exercise library will become one deployable application. The unified app
keeps both direct body-area browsing and visual discovery, with one normalized content snapshot,
one compliance pipeline, and one safety model. `patient-library/` remains the live reference and
rollback target during migration; it is not edited as part of this decision. Anatomy data may
reference stable published library IDs, but must not duplicate exercise instructions, dosage, or
safety content. This resolves the earlier “additive front door” positioning while preserving the
separate-app migration safety boundary until the cutover is proven.

### A-012 · Full-body 3D is the signature experience
**2026-08-26 · Afsal**
On capable devices the primary locator is a full-body 3D human: broad region selection highlights
and zooms, an on-demand regional scene supports exact-zone selection, and the app asks whether
that is the exact place of discomfort before safety and education. The accessible 2D map and
semantic controls remain a complete equivalent for keyboard users, constrained devices, WebGL
failure, and reduced-complexity preference. 3D is primary in product intent but progressive in
delivery. Models and hotspots require size budgets, lazy loading, stable logical IDs, rendered
visual QA, and clinician verification. Educational “usual scenarios” are reviewed cautious
content, never an inferred explanation for the individual user.

### A-013 · Superseded planning is archived, not deleted
**2026-08-26 · Afsal**
The earlier anatomy-only backlog, module briefs, build prompts, and agent-control documents are
preserved under `docs/archive/legacy-2026-08-26/`. They are not implementation instructions for
the unified product. This keeps all useful history recoverable while leaving one active PRD,
architecture, safety contract, and build sequence for future work.

### A-014 · Unified shell starts with three first-class entry points
**2026-08-26 · Afsal**
The unified app home presents Find a body area, Stretching, and Exercise Protocols as equal
workflows. The visual locator is not a mandatory gate for patients who already know their area.
The canonical locator URL is `/find-my-area/`; `/find-my-pain` remains as a compatibility route
until redirects and external links are audited.

### A-015 · Draft now, publish only after review; motion is optional clinical media
**2026-08-26 · Afsal**
Content and media production may proceed before clinician review so the product does not stall, but
all builder- or AI-assisted clinical material remains draft, source-linked, visibly unreviewed, and
excluded from patient routes. Exercise motion is an optional enhancement after an approved still,
not a replacement for text. Prefer deterministic rigged 3D or licensed footage; unconstrained
image-to-video is not used for patient demonstrations because plausible joint drift is a safety
risk. Every motion asset needs poster fallback, explicit playback, reduced-motion behavior, and
separate movement-fidelity approval.

### A-016 · The product is a clinic-guided physiotherapy handbook
**2026-08-26 · Afsal**
The primary repeat-use workflow is clinician handoff: a physiotherapist tells the patient which
exercise or body area to review and shares a stable link, QR code, or printed handout. The patient
lands directly on that canonical content without an account or mandatory locator flow. The full-body
3D human is the signature exploration route for understanding a body area and finding general
published stretches and exercises. Direct handoff, head-to-toe browsing, search, and 3D exploration
are equal entrances into one content system; none duplicates clinical records or stores assignments.

### A-001 · Separate app, additive to the library
**2026-08-26 · Afsal**
Anatomy Explorer is its own Astro app in `anatomy-explorer/`, not a route inside the exercise
library. The library is live and in a clinician's hands; a WebGL-capable interactive surface has
opposite non-functional requirements to a near-zero-JS content site. The two share a repository
and a build-time content snapshot, nothing else.

### A-002 · Three screens, not seven
**2026-08-26 · Afsal + Claude**
Locate → Confirm → Exercises, with the safety gate between the last two. The intro screen is cut:
"Where do you feel discomfort? → Explore the body" costs a tap and delivers nothing.

The three symptom questions are cut too. They cannot alter routing (routing is by area) or
education (education is per region), so they changed nothing — while costing three screens and
implying the app was working something out about the patient, the impression
`PRODUCT-BLUEPRINT.md` §8 exists to prevent.

### A-003 · Confirmation is where education begins
**2026-08-26 · Afsal + Claude**
The confirm step was a yes/no gate — two taps to learn nothing. It becomes the screen that says
something true about the spot the patient just chose.

Rationale: precision changes what they *read*, not where they route, and that is intentional — a
patient who points slightly wrong still lands somewhere useful. The value of the confirm step is
rapport, and *perceived behavioural control* is the only high-quality adherence predictor in the
library's `RESEARCH-FINDINGS.md`. Never tell the patient their answer was imprecise.

### A-004 · The muscle figure — body as output, not only input
**2026-08-26 · Afsal + Claude**
Every exercise shows which muscles it works, highlighted on a small body diagram.
`target_muscles_en` is populated on all 26 library items and already clinician-written, so this
adds **zero** new clinical content. The library's own research notes no incumbent shows target
muscles to patients.

This is what lets v1 ship a useful education layer while the clinician is still finishing the
exercise corpus.

### A-005 · Regions are derived from the library, never hardcoded
**2026-08-26 · Afsal**
A build-time snapshot of `areas.json` and `items.json` decides which regions exist. Before this,
the locator offered `upper-back` and `foot` (zero exercises — dead ends) and omitted `elbow`
(two exercises — unreachable). `check:anatomy` fails the build on drift.

### A-006 · Hotspots are generated from a shared joint table
**2026-08-26 · Afsal + Claude · inherits library D-015**
The silhouette and every hotspot derive from one set of joints, so a hotspot cannot drift off the
limb it names. Hand-authored coordinates produced a wrist marker floating off the arm and a lower
back tappable on the abdomen.

Two specifics that are the actual bug fixes: the hip hotspot anchors on the **trochanter**, not
the leg root, or the two sides collide at the midline; and `lower-back` is **back-view only**.

Library D-015 is the precedent: five of nine generated images were clinically wrong and all nine
looked professional. A wrong hotspot looks fine too. **Render it and look at it.**
Verified geometry: `reference/body-geometry/`.

### A-007 · The safety gate is a gate, not a question
**2026-08-26 · Afsal**
One screen, the eight approved triggers from `CLINICAL-SAFETY.md` §3 verbatim, before any
exercise handoff. No skip, no "I'm not sure" that routes onward, no route to an exercise from the
stop screen — including by browser back.

Before this the app collected `after-injury` and `burning-tingling` as answers and proceeded to
exercises regardless.

### A-008 · Nine modules, exclusive file ownership, parallel agents
**2026-08-26 · Afsal**
`AnatomyLocator.astro` at 416 lines meant every task touched one file, so parallel work was
impossible. M0 splits it per screen and freezes the type contract; after that three agents run at
once. Ownership table in `MODULE-HANDOFF.md`; an agent that needs a file it does not own stops
and reports.

### A-009 · GPT-5.6 Sol owns the visual modules
**2026-08-26 · Afsal**
M1, M4, M6 and M9 go to Sol because it takes vision input and can judge its own rendered output.
Claude takes structure, state and clinical language; Antigravity takes scripts and validation.
M0 ships `scripts/shoot.mjs` so every visual module has a repeatable render loop rather than
clicking around. A visual module is not finished until its agent has attached the images and said
what it saw.

### A-010 · v1 ships with zero new clinical prose
**2026-08-26 · Afsal**
The education layer is derived from `target_muscles_en` and gated on `status: 'published'`. The
total clinical ask for launch is one wording review of the emergency line. Rationale: the
clinician is mid-way through the *first* content corpus; a second one before that lands is the
failure `../patient-library/BUILD-PLAN.md` was written to prevent.

---

## Open — needs the clinician

See `CLINICIAN-QUESTIONS.md`. **Note that the library's D1–D8 were never answered** — the brief
form in `../patient-library/prototype/` was built and appears never to have come back. Those
questions are now older and cheaper to answer than they will ever be again.

---

## Deliberately not doing

Diagnosis · probability or cause · accounts · server-side symptom storage · pain scale, type or
duration questions · multi-spot charting · 3D in the locator · analytics.

Each was considered and rejected with a reason in `PRD.md`. If one comes back, write a new
decision entry rather than quietly reversing.

---

## Risks

- **The boundary between education and symptom-checking depends on `check:anatomy`.** The script
  now exists and is declared, but the current dependency installation cannot execute the full
  check suite. Verify it with the correct toolchain before relying on it, and never weaken it to
  make a build green; fix the content or mapping instead.
- **A wrong hotspot looks right.** Library D-015, restated. Visual verification is not optional.
- **Agents wander.** `astro.config.mjs` was deleted from the live app and sat missing for days.
  The `patient-library/` write-block hook and the `LIVE APP TOUCHED?` review line exist for this.
- **D8, inherited.** Whether a regulator reads this as education or advertisement. A body map is
  the most product-like surface on the site and therefore most exposed. No outcome claims, no
  condition names, no booking CTA.
